execute as @a run function moldomre:player_tick
