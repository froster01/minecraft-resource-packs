function moldomre:holding_emerald_amulet
function moldomre:holding_soul_healer

scoreboard players enable @a vanillaPlusGearRecipes
scoreboard players enable @a vanillaPlusHatRecipes
scoreboard players enable @a vanillaPlusExtraRecipes
scoreboard players enable @a vanillaPlusFoodRecipes
scoreboard players enable @a vanillaPlusDyes

execute as @a[scores={vanillaPlusGearRecipes=1}] run function moldomre:reset_gear_recipes
execute as @a[scores={vanillaPlusHatRecipes=1}] run function moldomre:reset_hat_recipes
execute as @a[scores={vanillaPlusExtraRecipes=1}] run function moldomre:reset_extra_recipes
execute as @a[scores={vanillaPlusFoodRecipes=1}] run function moldomre:reset_food_recipes
execute as @a[scores={vanillaPlusDyes=1}] run function moldomre:reset_dye_display