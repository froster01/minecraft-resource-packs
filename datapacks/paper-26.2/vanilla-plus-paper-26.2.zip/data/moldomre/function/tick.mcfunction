scoreboard players add #clock vanillaPlusTick 1
execute if score #clock vanillaPlusTick matches 10.. run function moldomre:slow_tick
