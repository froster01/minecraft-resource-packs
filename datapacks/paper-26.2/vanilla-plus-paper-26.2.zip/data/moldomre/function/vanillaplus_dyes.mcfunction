tellraw @s {"bold":true,"text":"Unique Dyes for Elytra, Books, Beanies, and Bundles:","underlined":true}

tellraw @s {"color":"#C890F0","text":"Amethyst: Amethyst Shard"}
tellraw @s {"color":"#F7BA17","text":"Cheddar: Yellow Dye + Orange Dye"}
tellraw @s {"color":"#00A0FF","text":"Azure: Blue Dye + Light Blue Dye"}
tellraw @s {"color":"#71533D","text":"Classic: Brown Dye + Yellow Dye (Only for Books and Bundles)"}
tellraw @s {"color":"#D86F4A","text":"Copper: Copper Ingot"}
tellraw @s {"color":"#E23150","text":"Coral: Red Dye + Magenta Dye"}
tellraw @s {"color":"#4AEDD9","text":"Diamond: Diamond"}
tellraw @s {"color":"#5AF495","text":"Emerald: Emerald"}
tellraw @s {"color":"#FDF55F","text":"Golden: Gold Ingot"}
tellraw @s {"color":"#6446EC","text":"Indigo: Blue Dye + Purple Dye"}
tellraw @s {"color":"#D8D8D8","text":"Iron: Iron Ingot"}
tellraw @s {"color":"#7497EA","text":"Lapis: Lapis Lazuli"}
tellraw @s {"color":"#CBAEE7","text":"Lavender: Purple Dye + Light Blue Dye"}
tellraw @s {"color":"#7AB026","text":"Light Green: Lime Dye + Green Dye"}
tellraw @s {"color":"#493D3F","text":"Netherite: Netherite Ingot (Makes the item Fire Resistant)"}
tellraw @s {"color":"#FAD2B2","text":"Peach: Orange Dye + White Dye"}
tellraw @s {"color":"#EAE5DE","text":"Quartz: Nether Quartz"}
tellraw @s {"color":"#FF0000","text":"Redstone: Redstone Dust"}
tellraw @s {"color":"#F3791B","text":"Resin: Resin Brick"}
tellraw @s {"color":"#53DDD3","text":"Seafoam: Cyan Dye + Lime Dye"}
tellraw @s {"color":"#ECF7FB","text":"Wings: Feather (Elytra Only)"}