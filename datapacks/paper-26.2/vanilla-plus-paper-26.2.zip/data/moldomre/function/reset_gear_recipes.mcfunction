scoreboard players reset @s vanillaPlusGearRecipes

function moldomre:recipes_gear