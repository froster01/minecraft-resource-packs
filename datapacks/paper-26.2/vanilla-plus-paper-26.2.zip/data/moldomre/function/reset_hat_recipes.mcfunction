scoreboard players reset @s vanillaPlusHatRecipes

function moldomre:recipes_hat