scoreboard players reset @s vanillaPlusExtraRecipes

function moldomre:recipes_extra