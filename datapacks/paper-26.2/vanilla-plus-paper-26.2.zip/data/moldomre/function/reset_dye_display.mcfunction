scoreboard players reset @s vanillaPlusDyes

function moldomre:vanillaplus_dyes