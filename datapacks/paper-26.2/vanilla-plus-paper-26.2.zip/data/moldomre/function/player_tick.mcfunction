execute if items entity @s weapon.offhand minecraft:poisonous_potato[custom_data="{moldomre:emerald_amulet}"] run effect give @s resistance 1 0 false
execute if items entity @s weapon.offhand minecraft:poisonous_potato[custom_data="{moldomre:soul_healer}"] run effect give @s regeneration 1 0 false

scoreboard players enable @s vanillaPlusGearRecipes
scoreboard players enable @s vanillaPlusHatRecipes
scoreboard players enable @s vanillaPlusExtraRecipes
scoreboard players enable @s vanillaPlusFoodRecipes
scoreboard players enable @s vanillaPlusDyes

execute if score @s vanillaPlusGearRecipes matches 1 run function moldomre:reset_gear_recipes
execute if score @s vanillaPlusHatRecipes matches 1 run function moldomre:reset_hat_recipes
execute if score @s vanillaPlusExtraRecipes matches 1 run function moldomre:reset_extra_recipes
execute if score @s vanillaPlusFoodRecipes matches 1 run function moldomre:reset_food_recipes
execute if score @s vanillaPlusDyes matches 1 run function moldomre:reset_dye_display
