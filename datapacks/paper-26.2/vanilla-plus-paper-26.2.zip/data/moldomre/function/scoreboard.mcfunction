scoreboard objectives add vanillaPlusGearRecipes trigger
scoreboard objectives add vanillaPlusHatRecipes trigger
scoreboard objectives add vanillaPlusExtraRecipes trigger
scoreboard objectives add vanillaPlusFoodRecipes trigger
scoreboard objectives add vanillaPlusDyes trigger
scoreboard objectives add vanillaPlusTick dummy
