scoreboard players reset @s vanillaPlusFoodRecipes

function moldomre:recipes_food