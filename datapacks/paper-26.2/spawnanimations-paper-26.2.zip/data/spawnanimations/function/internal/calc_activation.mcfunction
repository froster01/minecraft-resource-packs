##by Tschipcraft
# @s/~ ~ ~ is tested entity; $global is player position

# Get position
data modify storage spawnanimations:temp Pos set from entity @s Pos
execute store result score @s ts.sa.x run data get storage spawnanimations:temp Pos[0]
execute store result score @s ts.sa.y run data get storage spawnanimations:temp Pos[1]
execute store result score @s ts.sa.z run data get storage spawnanimations:temp Pos[2]

# Calculate diff
scoreboard players operation @s ts.sa.x -= $global ts.sa.x
scoreboard players operation @s ts.sa.y -= $global ts.sa.y
scoreboard players operation @s ts.sa.z -= $global ts.sa.z

# Make sure value is positive
execute if score @s ts.sa.x matches ..0 run scoreboard players operation @s ts.sa.x *= #minus ts.sa.x
execute if score @s ts.sa.y matches ..0 run scoreboard players operation @s ts.sa.y *= #minus ts.sa.x
execute if score @s ts.sa.z matches ..0 run scoreboard players operation @s ts.sa.z *= #minus ts.sa.x

# Add distances together
scoreboard players operation @s ts.sa.x += @s ts.sa.y
scoreboard players operation @s ts.sa.x += @s ts.sa.z

# Test
execute if score @s ts.sa.x <= $activation_dist ts.sa.settings as @s[type=!#spawnanimations:always_poof_animation] run function spawnanimations:internal/animation/dig_up/start
execute if score @s ts.sa.x <= $activation_dist ts.sa.settings as @s[type=#spawnanimations:always_poof_animation] run function spawnanimations:internal/animation/dig_up/verify_in_air


execute if score $activation_mode ts.sa.settings matches -1..0 if score @s ts.sa.x > $activation_dist ts.sa.settings run function spawnanimations:internal/animation/dig_up/check_failed
